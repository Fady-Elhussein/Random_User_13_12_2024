package com.example.random_user

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
